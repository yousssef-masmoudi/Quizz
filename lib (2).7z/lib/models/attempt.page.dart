import 'package:quiz_prj/models/question_attempt.page.dart';

class Attempt {
  final DateTime date;
  final int score;
  final int totalQuestions;
  final String difficulty;
  final List<QuestionAttempt> questions;

  Attempt({
    required this.date,
    required this.score,
    required this.totalQuestions,
    required this.difficulty,
    required this.questions,
  });
}
