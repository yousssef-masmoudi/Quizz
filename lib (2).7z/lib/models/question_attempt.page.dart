class QuestionAttempt {
  final String questionText;
  final String selectedAnswer;
  final String correctAnswer;

  QuestionAttempt({
    required this.questionText,
    required this.selectedAnswer,
    required this.correctAnswer,
  });
}
